import cv2
import numpy as np

# Loads an image and converts it to the HSV color space.
# Defines color ranges for yellow, light gray, gray, and dark gray.
# Creates masks to isolate regions in the image corresponding to each color.
# Converts the image to grayscale for dark gray detection and applies thresholding to create a mask.
# For each color mask:
# Finds contours in the mask.
# Calculates the area and centroid of each contour.
# Prints the color, area, and centroid coordinates.
# Draws the area information near the centroid on the original image.
# Displays the annotated image with color-specific area information.

image = cv2.imread('./data/fig1.jpg')
hsv_image = cv2.cvtColor(image, cv2.COLOR_BGR2HSV)

yellow_lower = np.array([20, 100, 100])
yellow_upper = np.array([30, 255, 255])

light_gray_lower = np.array([0, 0, 200])
light_gray_upper = np.array([180, 30, 255])

gray_lower = np.array([0, 0, 100])
gray_upper = np.array([180, 30, 200])


dark_gray_lower = np.array([0, 0, 20])
dark_gray_upper = np.array([180, 30, 100])


yellow_mask = cv2.inRange(hsv_image, yellow_lower, yellow_upper)
light_gray_mask = cv2.inRange(hsv_image, light_gray_lower, light_gray_upper)
gray_mask = cv2.inRange(hsv_image, gray_lower, gray_upper)


gray_image = cv2.cvtColor(image, cv2.COLOR_BGR2GRAY)


_, dark_gray_mask = cv2.threshold(gray_image, 50, 255, cv2.THRESH_BINARY)


for mask, color in zip([yellow_mask, light_gray_mask, gray_mask, dark_gray_mask],
                       ["Yellow", "Light Gray", "Gray", "Dark Gray"]):
    contours, _ = cv2.findContours(mask, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)
    for contour in contours:
        
        area = cv2.contourArea(contour)
       
        M = cv2.moments(contour)
        if M["m00"] != 0:
            cx = int(M["m10"] / M["m00"])
            cy = int(M["m01"] / M["m00"])
            
            print(f"Color: {color}, Area: {area} pixels, Centroid: ({cx}, {cy})")
            area_text = f"area:{area}"
           
            cv2.putText(image, area_text, (cx - 60, cy), cv2.FONT_HERSHEY_SIMPLEX, 0.5, (255, 255, 255), 1)


cv2.imshow("Image", image)
cv2.waitKey(0)
cv2.destroyAllWindows()


