
import cv2
import numpy as np

# Converting the image to grayscale and applying binary thresholding.
# Finding contours (shapes) in the binary image.
# Approximating the contours to identify potential rectangles.
# Calculating shape parameters and centroids.
# Classifying shapes as rectangles or squares.
# Drawing rectangles and centroids on the original image.
# Displaying the result with shape information.

image = cv2.imread('./data/rect1.jpg')
gray = cv2.cvtColor(image, cv2.COLOR_BGR2GRAY)
_, thresh = cv2.threshold(gray, 240, 255, cv2.THRESH_BINARY)
contours, _ = cv2.findContours(thresh, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)

rectangles = []
squares = []

for contour in contours:
    
    epsilon = 0.04 * cv2.arcLength(contour, True)
    approx = cv2.approxPolyDP(contour, epsilon, True)

    
    perimeter = cv2.arcLength(contour, True)
    M = cv2.moments(contour)
    if M["m00"] != 0:
        cx = int(M["m10"] / M["m00"])
        cy = int(M["m01"] / M["m00"])
    else:
        cx, cy = 0, 0

    
    if len(approx) == 4:
        x, y, w, h = cv2.boundingRect(contour)
        aspect_ratio = float(w) / h

        
        tolerance = 0.1

        if 1 - tolerance <= aspect_ratio <= 1 + tolerance:
            squares.append((x, y, w, h, perimeter, (cx, cy)))
        else:
            rectangles.append((x, y, w, h, perimeter, (cx, cy)))


result_image = image.copy()
for x, y, w, h, p, (cx, cy) in rectangles:
    cv2.rectangle(result_image, (x, y), (x + w, y + h), (0, 255, 0), 2)
    cv2.circle(result_image, (cx, cy), 5, (0, 0, 255), -1)
    print(f"Rectangle found - Perimeter: {p}, Centroid: ({cx}, {cy})")

for x, y, w, h, p, (cx, cy) in squares:
    cv2.rectangle(result_image, (x, y), (x + w, y + h), (255, 0, 0), 2)
    cv2.circle(result_image, (cx, cy), 5, (0, 0, 255), -1)
    print(f"Square found - Perimeter: {p}, Centroid: ({cx}, {cy})")


cv2.imshow('Result', result_image)
cv2.waitKey(0)
cv2.destroyAllWindows()

