import cv2
import numpy as np

def check_blurred(image):
    
    #The function checks if an image is blurred based on its sharpness.

    #Parameters:
    #- image (numpy.ndarray): The image to be checked for blurriness.

    #Returns:
    #- bool: True if the image is blurred, False otherwise.

    #This function calculates the Laplacian variance of the input image, which is a measure of image sharpness.
    #It then compares this variance to a predefined threshold (100.0). If the variance is less than the threshold,
    #the function returns True, indicating that the image is blurred, this means its sharpness is less than the threshold defined. Otherwise, it returns False.
    
    laplacian_varience=cv2.Laplacian(image, cv2.CV_64F).var() #calculating laplacian varience , calculating the sharpnes of an image
    
    threshold = 100.0 # assigning the threshold value

    if laplacian_varience < threshold:  
     return True
    
    else:
     return False
    

image=cv2.imread("./data/fig5.jpg", cv2.IMREAD_GRAYSCALE)  
blurred_image=cv2.imread("./data/fig5_blur.jpg",cv2.IMREAD_GRAYSCALE)

check_if_image_blurred=check_blurred(image) 
check_if_blurred_image_blurred=check_blurred(blurred_image)

if check_if_image_blurred and  not check_if_blurred_image_blurred: 
 print("fig 5 is blurred and fig5_blur is not blurred")
 cv2.imshow("Blurred image", image)
 cv2.imshow("original image", blurred_image)

elif not check_if_image_blurred and check_if_blurred_image_blurred:
  print("fig5_blurr is a blurr image and the normal image is not blurr")
  cv2.imshow("Blurred image", blurred_image)
  cv2.imshow("original image", image)

cv2.waitKey(0)
cv2.destroyAllWindows()





