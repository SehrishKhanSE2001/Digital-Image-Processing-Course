
import cv2
import numpy as np

def check_gender(image_path_with_background, image_path_with_no_background=None):
    """
   This function determine the gender of a person based on the presence of hair in an image. 
    TheParameters:
    - image_path_with_background (str): File path of the image with the person against a background.
    - image_path_with_no_background (str, optional): File path of an image with the person isolated from the background.

    Returns:
    - str: male or female
    The code then compares max_y_cord_hair to face_length_y:

     If max_y_cord_hair is greater than or equal to face_length_y, it suggests that the detected hair extends below the face. In this case, the code returns "female," implying that the person in the image is likely female (no hair is present above the face).
     If max_y_cord_hair is less than face_length_y, it implies that the detected hair does not extend below the face. In this scenario, the code returns "male," indicating that the person is likely male (has hair on top of the face).

    This function analyzes two input images: one with the person against a background and another with
    the person isolated from the background (if not provided, it's created) In this case it is created. It performs the following steps:

    1. Remove the background from `image path with background` if `image apth with no background` is not provided:
       a. Read the image using OpenCV (cv2).
       b. Isolate the person's face by creating a mask for white regions.
       c. Save the isolated face as "face.png."

    2. Read the isolated face image.

    3. Convert the face image to grayscale.

    4. Find contours to detect the face's boundaries.

    5. Identify the largest contour (the face outline).

    6. Calculate the vertical length of the face.

    7. Read the background image (`image_path_with_background`).

    8. Convert the background image to HSV color space.

    9. Create a mask to detect black regions (hair).

    10. Find hair contours.

    11. Determine the highest point of the hair (maximum y-coordinate).

    12. Compare hair position with the face's vertical length:
        - If hair extends below the face, it's likely a female (no hair).
        - If not, it's likely a male (has hair).

    13. Return "female" or "male" based on the presence of hair.
    """
    if image_path_with_no_background is None:
        image = cv2.imread(image_path_with_background)
        lower_white = np.array([200, 200, 200])
        upper_white = np.array([255, 255, 255])
        mask = cv2.inRange(image, lower_white, upper_white)
        mask = cv2.bitwise_not(mask)
        result = cv2.bitwise_and(image, image, mask=mask)
        output_file = "face.png"
        cv2.imwrite(output_file, result)
        image_path_with_no_background = output_file

    face_img_no_bg = cv2.imread(image_path_with_no_background)
    gray_face = cv2.cvtColor(face_img_no_bg, cv2.COLOR_BGR2GRAY)
    contours, _ = cv2.findContours(gray_face, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)
    largest_contour = max(contours, key=cv2.contourArea)
    y_coordinates = [point[0][1] for point in largest_contour]
    face_length_y = max(y_coordinates) - min(y_coordinates)

    face_img_bg = cv2.imread(image_path_with_background)
    hsv_image = cv2.cvtColor(face_img_bg, cv2.COLOR_BGR2HSV)
    lower_black = np.array([0, 0, 0], dtype=np.uint8)
    upper_black = np.array([180, 255, 30], dtype=np.uint8)
    black_mask = cv2.inRange(hsv_image, lower_black, upper_black)
    contours, _ = cv2.findContours(black_mask, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)
    max_y_cord_hair = 0

    for contour in contours:
        max_cont_y = max(point[0][1] for point in contour)

        if max_cont_y > max_y_cord_hair:
            max_y_cord_hair = max_cont_y

    if max_y_cord_hair >= face_length_y:
        return "female"
    else:
        return "male"

image1_path = "./data/fig3.jpg"
image2_path = "./data/fig4.jpg"
gender1 = check_gender(image1_path)
gender2 = check_gender(image2_path)
print(f"Gender in fig3 is:  {gender1}")
print(f"Gender in fig4 is {gender2}")

