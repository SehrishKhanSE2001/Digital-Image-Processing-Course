import cv2
import numpy as np

# Loads two images: one containing colored areas and another with a red arrow.
# Converts the first image to the HSV color space.
# Defines color ranges for yellow, light gray, gray, and dark gray.
# Creates masks for each color range by thresholding in the HSV space.
# Converts the first image to grayscale and applies thresholding to create a mask for dark gray.
# Creates a mask for the red arrow in the second image.
# Calculates the area of the red arrow and the overlapping areas between each color mask and the red arrow mask.
# Calculates the percentage of the red arrow area covered by each color.
# Prints the percentage area for each color.

image = cv2.imread('./data/fig1.jpg')
image_with_arrow = cv2.imread('./data/fig2.jpg')


hsv_image = cv2.cvtColor(image, cv2.COLOR_BGR2HSV)


yellow_lower = np.array([20, 100, 100])
yellow_upper = np.array([30, 255, 255])

light_gray_lower = np.array([0, 0, 200])
light_gray_upper = np.array([180, 30, 255])

gray_lower = np.array([0, 0, 100])
gray_upper = np.array([180, 30, 200])


dark_gray_lower = np.array([0, 0, 20])
dark_gray_upper = np.array([180, 30, 100])


yellow_mask = cv2.inRange(hsv_image, yellow_lower, yellow_upper)
light_gray_mask = cv2.inRange(hsv_image, light_gray_lower, light_gray_upper)
gray_mask = cv2.inRange(hsv_image, gray_lower, gray_upper)


gray_image = cv2.cvtColor(image, cv2.COLOR_BGR2GRAY)


_, dark_gray_mask = cv2.threshold(gray_image, 50, 255, cv2.THRESH_BINARY)


red_arrow_mask = cv2.inRange(image_with_arrow, (0, 0, 200), (50, 50, 255))  


colored_areas = {
    "Yellow": cv2.countNonZero(cv2.bitwise_and(yellow_mask, red_arrow_mask)),
    "Light Gray": cv2.countNonZero(cv2.bitwise_and(light_gray_mask, red_arrow_mask)),
    "Gray": cv2.countNonZero(cv2.bitwise_and(gray_mask, red_arrow_mask)),
    "Dark Gray": cv2.countNonZero(cv2.bitwise_and(dark_gray_mask, red_arrow_mask))
}


total_red_arrow_area = cv2.countNonZero(red_arrow_mask)


for color, area in colored_areas.items():
    percentage_area = (area / total_red_arrow_area) * 100
    print(f"{color}: {percentage_area:.2f}%")