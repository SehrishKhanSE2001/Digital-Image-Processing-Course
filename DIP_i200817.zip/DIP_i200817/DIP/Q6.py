import cv2
import numpy as np
import os

def remove_image_background(input_path):
    
#In remove_image_background:

#Remove Background: This function takes an input image and removes the white background by creating a mask based on specified color ranges. 
# It then extracts bone segments from the original image and saves them as separate images, preserving their individual shapes and sizes.

    img = cv2.imread(input_path)

    if img is None:
        print("Error: Failed to read the input image.")
        return

    lower_white = np.array([200, 200, 200])
    upper_white = np.array([255, 255, 255])

    mask = cv2.inRange(img, lower_white, upper_white)
    mask = cv2.bitwise_not(mask)

    bones = cv2.bitwise_and(img, img, mask=mask)

    contours, _ = cv2.findContours(mask, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)

    for i, contour in enumerate(contours):
        x, y, w, h = cv2.boundingRect(contour)

        bone_segment = bones[y:y + h, x:x + w]

        output_file = f"bone_{i + 1}.png"
        cv2.imwrite(output_file, bone_segment)

        print(f"Bone {i + 1}: Height: {h}, Width: {w}")

def extract_color_bones(input_image_path, output_folder):
   # Color Segmentation: This function extracts bone segments of different colors (yellow, blue, green, skin-orange, purple) from the input image by applying color range masks in the HSV color space. 
   # It processes each color-segmented bone and stores them as separate image segments.


# Processing for Each Color:

# For each specified color, it creates a mask to highlight the bone segments of that color.
# The mask is applied to the input image to extract the bone segment in that color.
# Each extracted bone segment is stored in a dictionary with the color name as the key.
# Special Case Handling (Blue Color Range):

# A special case is handled for the "blue_color_range" bone segment.
# It calculates the dimensions of the "purple" bone segment by finding the largest contour within its thresholded segment.
# The dimensions of the "blue_color_range" bone segment are adjusted based on the calculated "purple" dimensions.
# Iterating Over Processed Bone Segments:

# The function processes each extracted bone segment one by one.
# For each segment, it converts it to grayscale, applies thresholding to isolate the bone shape, and detects contours.
# The largest contour is selected as the bone shape, and its dimensions (height and width) are calculated.
# If the segment is of the "blue_color_range," its dimensions are adjusted based on the "purple" bone segment.
# Printing and Saving:

# Information about each bone segment, including its color, height, and width, is printed.
# The processed bone segments are saved as individual image files in an output folder with meaningful filenames.
    
    img = cv2.imread(input_image_path)

    if img is None:
        print("Error: Failed to read the image with removed background.")
        return

    color_ranges = {
        "yellow": [(20, 100, 100), (30, 255, 255)],
        "blue_color_range": [(100, 50, 50), (120, 255, 255)],
        "green": [(45, 100, 100), (85, 255, 255)],
        "skin-orange": [(5, 100, 100), (15, 255, 255)],
        "purple": [(110, 50, 50), (130, 255, 255)]
    }

    os.makedirs(output_folder, exist_ok=True)

    bone_images = {}

    purple_width = 0
    purple_height = 0

    for color, (lower_range, upper_range) in color_ranges.items():
        hsv_img = cv2.cvtColor(img, cv2.COLOR_BGR2HSV)
        mask = cv2.inRange(hsv_img, np.array(lower_range), np.array(upper_range))
        bone_segment = cv2.bitwise_and(img, img, mask=mask)
        bone_images[color] = bone_segment

    gray_segment = cv2.cvtColor(bone_segment, cv2.COLOR_BGR2GRAY)
    _, thresh = cv2.threshold(gray_segment, 1, 255, cv2.THRESH_BINARY)
    contours, _ = cv2.findContours(thresh, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)

    if "purple" in color_ranges and contours:
        largest_contour = max(contours, key=cv2.contourArea)
        x, y, w, h = cv2.boundingRect(largest_contour)
        purple_width = w
        purple_height = h

    for color, (lower_range, upper_range) in color_ranges.items():
        hsv_img = cv2.cvtColor(img, cv2.COLOR_BGR2HSV)
        mask = cv2.inRange(hsv_img, np.array(lower_range), np.array(upper_range))
        bone_segment = cv2.bitwise_and(img, img, mask=mask)
        bone_images[color] = bone_segment

    for i, (color, segment) in enumerate(bone_images.items(), 1):
        gray_segment = cv2.cvtColor(segment, cv2.COLOR_BGR2GRAY)
        _, thresh = cv2.threshold(gray_segment, 1, 255, cv2.THRESH_BINARY)
        contours, _ = cv2.findContours(thresh, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)
        if contours:
            largest_contour = max(contours, key=cv2.contourArea)
            x, y, w, h = cv2.boundingRect(largest_contour)
            if color == "blue_color_range":
                w = w - purple_width
                h = h - purple_height
            print(f"Segment of bone {i} , Color: ({color}): Height: {h} and Width: {w}")

            output_file = os.path.join(output_folder, f"bone_{i}_{color}.png")
            cv2.imwrite(output_file, segment)

if __name__ == "__main__":
    input_image_path = "./data/finger-bones.jpg"  # Replace with your input image file path
    output_directory = "segments"  # Directory to save all bone segments

    remove_image_background(input_image_path)

    extract_color_bones("bone_1.png", output_directory)


